﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager thisManager = null;

    public Text CoinCounter;
    private GameObject[] coins;
    [SerializeField]
    private int CoinNum;

    private void Awake()
    {
        if (thisManager == null)
            thisManager = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        coins = GameObject.FindGameObjectsWithTag("Coin");
        CoinNum = coins.Length;
    }

    // Update is called once per frame
    void Update()
    {
        CoinCounter.text = "Coins Remaining : " + CoinNum;
    }

    public void CoinCollected()
    {
        CoinNum -= 1;
        if (CoinNum <= 0)
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void OnLose()
    {
        SceneManager.LoadScene("GameLose");
    }
}
